﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace T37Dice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Tap a button to roll the dice");

            Console.ReadLine();

            int playerRandomNum;

            Random random = new Random();
            playerRandomNum = random.Next(1, 7);

            Console.WriteLine("Dice, one test throw value is " + playerRandomNum);

            Console.Write("Give a number ");

            //int x = Convert.ToInt32(Console.ReadLine());
            
            for (int i = 0; i == 5; i++)
            {
                //playerRandomNum = random.Next(1, 7);

                Console.WriteLine("You rolled a ");
                Console.Read();
            }
            
        }
    }
}
