﻿namespace Consumption
{
    class Demo
    {
        static void Main(string[] args)
        {

            Console.Write("Enter distance traveled: ");
            string val = Console.ReadLine();

            if (int.TryParse(val, out var distance))
            {
                Random rnd = new();

                int liter = rnd.Next(6, 10);
                double price = 2.5;

                double consump = (distance / 100) * liter;
                double cost = price * consump;

                Console.WriteLine("Fuel consumption is " + consump + " liters and it costs " + cost + " euros.");
            }
            else
                Console.WriteLine("Please input a number");
        }
    }
}