﻿namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            string palin = string.Empty;
            Console.WriteLine("Enter String");
            palin = Console.ReadLine();

            char[] temp = palin.ToCharArray();
            Array.Reverse(temp);
            string palout = new string(temp);

            if (palin.ToLower() == (palout.ToLower()))
            {
                Console.WriteLine("Ah!! Its Palindrome");
            }
            else
            {
                Console.WriteLine("Damn Buddy!! its not a palidrome");
            }
        }
    }
}