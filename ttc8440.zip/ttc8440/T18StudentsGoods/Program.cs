﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T18StudentsGood
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FirstShelf shelf1 = new FirstShelf()
            {
                Books = "Old",
                Laptop = "No",
                OldVersion = "Related to programming language"
            };

            Console.WriteLine(shelf1.ShowInfo());

            SecondShelf shelf2 = new SecondShelf()
            {
                Books = "JavaScript, C#, Python, Hacking",
                Laptop = "Yes",
                Electronics = "Laptop, iPad",
                DecorativeObjects = "FlowerVase, TableWatch",
                Magazine = "From JAMK"
            };

            Console.WriteLine(shelf2.ShowInfo());
            
            ThirdShelf shelf3 = new ThirdShelf()
            {
                Players = "CD & DVD Player",
                Books = "JavaScript, C#, Python, Hacking",
                Laptop = "No",
                CDs = "JavaScript, C#",
                DVDs = "Hacking, JavaScript, C#"

            };
            Console.WriteLine(shelf3.ShowInfo());
        }

    }
    public class BookShelf
    {
        public string Books { get; set; }
        public string Laptop { get; set; }


        public string Magazine { get; set; }
        public string CDs { get; set; }
        public string DVDs { get; set; }

    }
    public class FirstShelf : BookShelf
    {
        public string OldVersion { get; set; }
        public string ShowInfo()
        {
            return $"Shelf 1: {Books}\n{Laptop}\n{OldVersion}";
        }
    }
    public class SecondShelf : BookShelf
    {
        public string Electronics { get; set; }
        public string DecorativeObjects { get; set; }
        public string ShowInfo()
        {
            return $"\nShelf 2:\n{Books}\n{Electronics}\n{Magazine}\n{Laptop}\n{DecorativeObjects}";
        }
    }
    public class ThirdShelf : BookShelf
    {
        public string Players { get; set; }
        public string ShowInfo()
        {
            return $"\nShelf 3:\n{Books}\n{Players}\n{CDs}\n{DVDs}\n{Laptop}";
        }
    }
}
