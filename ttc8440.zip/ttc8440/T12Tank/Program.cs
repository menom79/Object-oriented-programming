﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T12Tank
{
    class Program
    {
        //public const float speedMax = 100;
        //public readonly float speedMax;
        static void Main(string[] args)
        {
            Tank tank1 = new Tank("Fury", "Manual", 1, 60, 180);
            
            Console.WriteLine(tank1.speedMax);

            AccelerateTo(5.2012F);
            SlowTo(6.254F);
            Console.ReadLine();
        }
     
        static void AccelerateTo(float acclrtion)
        {
            Console.WriteLine(acclrtion);
            
        }

        static void SlowTo(float slw)
        {
            Console.WriteLine(slw);
        }
    }
}
