﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T12Tank
{
    class Tank
    {
        public string name;
        public string type;
        private int crewNumber;
        public float speed;
        public float speedMax;


        public Tank(string aName, string aType, int aCrewNumber, float aSpeed, float aSpeedMax)
        {
            name = aName;
            type = aType;
            CrewNumber = aCrewNumber;
            speed = aSpeed;
            speedMax = aSpeedMax;

        }

        public int CrewNumber
        {
            get { return crewNumber; }

            // how to set initial value 4?
            set {
                if (value >= 2 && value <= 6)
                {
                    crewNumber = value;
                }
                else
                {
                    crewNumber = 4;
                }
            }
        }
    }
}
