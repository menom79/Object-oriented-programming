﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T13Elevator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.Write("Give a new floor number (1-5) > ");


                int floor = Convert.ToInt32(Console.ReadLine());

                FloorNumber(floor);

            } while (true);
        }

        static void FloorNumber(int floor)
        {
            if (floor <= 5 & floor >= 1)
            {
                Console.WriteLine("Elevator is now in floor : " + floor);
            }
            else if (floor <= 0)
            {
                Console.WriteLine("Floor is too small!");
            }
            else if (floor > 5)
            {
                Console.WriteLine("Floor is too big!");
            }
        }
    }
}
