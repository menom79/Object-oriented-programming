namespace School_Number
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double score = Convert.ToDouble(textScore.Text);
            if (score >= 60 && score<=70)
                lblGrade.Text = "5";
            else if (score >= 50 && score <=59)
                lblGrade.Text = "4";
            else if (score >= 40 && score <= 49)
                lblGrade.Text = "3";
            else if (score >= 30 && score <= 39)
                lblGrade.Text = "2";
            else if (score >= 20 && score <= 29)
                lblGrade.Text = "1";
            else if (score >= 0 && score <= 19)
                lblGrade.Text = "0";
            else lblGrade.Text = "Please Put correct form";
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void lblGrade_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }
    }
}