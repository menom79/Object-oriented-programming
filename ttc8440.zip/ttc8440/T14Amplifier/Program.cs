﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T13Elevator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.Write("Give a new volume value (0-100) > ");


                int volume = Convert.ToInt32(Console.ReadLine());

                Amplifier(volume);

            } while (true);
        }

        static void Amplifier(int volume)
        {
            if (volume >= 0 & volume <= 100)
            {
                Console.WriteLine("-> Amplifier volume is set to : " + volume);
            }
            else if (volume < 0)
            {
                Console.WriteLine("-> Too low volume - Amplifier volume is set to minimum : 0");
            }
            else if (volume > 100)
            {
                Console.WriteLine("-> Too much volume - Amplifier volume is set to maximum : 100");
            }
        }
    }
}
