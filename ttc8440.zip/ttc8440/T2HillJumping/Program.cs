﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T2HillJumping
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Give points: ");
            int point1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Give points: ");
            int point2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Give points: ");
            int point3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Give points: ");
            int point4 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Give points: ");
            int point5 = Convert.ToInt32(Console.ReadLine());

            int sum = point1 + point2 + point3 + point4 +point5;
            
            int min = Math.Min(Math.Min(Math.Min(Math.Min(point1, point2), point3), point4), point5);
            int max = Math.Max(Math.Max(Math.Max(Math.Max(point1, point2), point3), point4), point5);

            int result = sum - (min + max);

            string msg = "Total points are: " + result;

            Console.WriteLine(msg);

            Console.ReadLine();
        }
    }
}
