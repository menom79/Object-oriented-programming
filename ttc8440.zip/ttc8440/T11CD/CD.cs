﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CD
{
    internal class CD
    {
        public string artist;
        public string name;
        public string genre;
        public double price;

        public CD(string aArtist, String aName, string aGenre, double aPrice)
        {
            artist = aArtist;
            name = aName;
            genre = aGenre;
            price = aPrice;

        }

    }
}
