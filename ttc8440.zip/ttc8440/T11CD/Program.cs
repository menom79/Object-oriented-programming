﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CD
{
    class Program
    {
        static void Main(string[] args)
        {

            CD cd1 = new CD("Nightwish", "Endless Forms Most Beautiful", "Symphonic metal", 19.9);

            Console.WriteLine("CD:");

            Console.WriteLine("-Artist: " + cd1.artist);
            Console.WriteLine("-Name: " + cd1.name);
            Console.WriteLine("-Genre: " + cd1.genre);
            Console.WriteLine("-Price: " + "$" + cd1.price);

            Console.WriteLine("Songs:");

            string[] songs = { "Shudder Before the Beautiful", "Weak Fantasy", "Elan", "Yours Is an Empty Hope", "Our Decades in the Sun", "My Walden", "Endless Forms Most Beautiful", "Edema Ruh", "Alpenglow", "The Eyes of Sharbat Gula", "The Greatest Show on Earth" };
            string[] timing = { "06:29", "05:23", "04:45", "05:34", "06:37", "04:38", "05:07", "05:15", "04:45", "06:03", "24:00" };
            for (int i = 0; i < songs.Length; i++)
                for (int j = 0; i < timing.Length; i++)
                {
                    Console.WriteLine("-- Name: " + songs[i] + " - " + timing[i]);
                }

            Console.ReadLine();

        }
    }
}
