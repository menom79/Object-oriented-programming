﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;

namespace T5Names
{
    class Program
    {
        static void Main(string[] args)
        {
            int SortByYear(string[] c, string[] d)
            {
                int cYear = Convert.ToInt32(c[1]);
                int dYear = Convert.ToInt32(d[1]);
                if (cYear > dYear)
                {
                    return -1;
                }
                if (cYear == dYear)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            Console.WriteLine("Please, give names and birth year of a person.Empty input will stop the input.");

            List<string[]> a = new List<string[]>(1);

            while(true)
            {
                Console.Write("Give a name: ");
                string input = Console.ReadLine();
                if (input == "")
                {
                    break;
                }

                char[] cDividers = { ',' };
                string[] segments = input.Split(cDividers);
               
           
                a.Add(segments);
                
            }
            Console.WriteLine($"{a.Count} names are given.");
            
            a.Sort(SortByYear);

            int currentYear = DateTime.Now.Year;

            foreach (string[] b in a)
            {
                string name = b[0];
                int year = Convert.ToInt32(b[1]);
                int age = currentYear - year;

                Console.WriteLine(name + " is " + age + " years old.");
            }

            Console.ReadLine();
        }
    }
}
